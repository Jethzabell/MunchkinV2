// Initialize Firebase
var config = {
  apiKey: "AIzaSyBxNiW43QLES6cTIncOrOqTKbYpivgLM4w",
  authDomain: "veryfirst-e4512.firebaseapp.com",
  databaseURL: "https://veryfirst-e4512.firebaseio.com",
  projectId: "veryfirst-e4512",
  storageBucket: "veryfirst-e4512.appspot.com",
  messagingSenderId: "962525809825"
};
firebase.initializeApp(config);
